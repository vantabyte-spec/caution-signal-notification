import { useState, useEffect } from 'react';
import { Wifi } from 'lucide-react';

export function CacheNotice() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(24 * 60 * 60); // 24 hours in seconds
  const [isTapping, setIsTapping] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleNFCTap = () => {
    setIsTapping(true);
    setTimeout(() => {
      setIsUnlocked(true);
      setIsTapping(false);
    }, 1500);
  };

  return (
    <div className="w-full max-w-2xl aspect-[612/792] bg-black border-4 border-cyan-400 relative p-8 flex flex-col items-center shadow-[0_0_30px_rgba(0,255,255,0.5)]">
      {/* Warning Symbol */}
      <div className="mt-12 mb-8 flex flex-col items-center gap-2">
        <div className="relative w-20 h-20">
          <svg viewBox="0 0 80 80" className="w-full h-full">
            <path d="M40 10L20 50H60L40 10Z" fill="#ff00ff" className="drop-shadow-[0_0_10px_rgba(255,0,255,0.8)]" />
          </svg>
        </div>
        <div className="w-5 h-5 bg-magenta-500" style={{ backgroundColor: '#ff00ff', boxShadow: '0 0 10px rgba(255,0,255,0.8)' }} />
        <div className="w-5 h-5 rounded-full" style={{ backgroundColor: '#ff00ff', boxShadow: '0 0 10px rgba(255,0,255,0.8)' }} />
      </div>

      {/* Header */}
      <h1 className="text-4xl font-bold mb-4 text-cyan-400" style={{ fontFamily: 'Courier New, monospace', textShadow: '0 0 20px rgba(0,255,255,0.8)' }}>
        CAUTION
      </h1>
      <p className="text-xl mb-6 text-magenta-400" style={{ fontFamily: 'Courier New, monospace', textShadow: '0 0 15px rgba(255,0,255,0.6)' }}>
        ACTIVE SIGNAL DETECTED
      </p>

      {/* Divider */}
      <div className="w-full max-w-md h-0.5 bg-cyan-400 mb-8" style={{ boxShadow: '0 0 10px rgba(0,255,255,0.6)' }} />

      {/* Description */}
      <div className="text-center mb-8 text-cyan-300" style={{ fontFamily: 'Courier New, monospace' }}>
        <p className="text-base">A DIGITAL SUPPLY CACHE HAS BEEN</p>
        <p className="text-base">GEO-LOCKED TO THIS LOCATION.</p>
      </div>

      {/* Contents Box */}
      <div className="border-2 border-magenta-400 border-dashed px-12 py-8 mb-12" style={{ boxShadow: '0 0 15px rgba(255,0,255,0.4)' }}>
        <p className="text-center font-bold mb-4 text-cyan-400" style={{ fontFamily: 'Courier New, monospace' }}>
          CONTAINS:
        </p>
        <div className="space-y-2 text-magenta-300" style={{ fontFamily: 'Courier New, monospace' }}>
          <p className="text-center">[ 500 D.O.P.E. CREDITS ]</p>
          <p className="text-center">[ UNRELEASED AUDIO STEMS ]</p>
        </div>
      </div>

      {/* NFC Tap Area */}
      <div className="mb-8">
        <button
          onClick={handleNFCTap}
          disabled={isUnlocked}
          className={`relative w-32 h-32 rounded-full border-4 flex items-center justify-center transition-all ${
            isTapping ? 'animate-pulse border-magenta-400 bg-magenta-500' : 'border-cyan-400 hover:bg-cyan-950'
          } ${isUnlocked ? 'bg-magenta-500 border-magenta-400' : ''}`}
          style={!isTapping && !isUnlocked ? { boxShadow: '0 0 20px rgba(0,255,255,0.5)' } : isTapping ? { boxShadow: '0 0 30px rgba(255,0,255,0.8)' } : { boxShadow: '0 0 30px rgba(255,0,255,0.8)' }}
        >
          {isTapping ? (
            <Wifi className="w-8 h-8 text-cyan-400" />
          ) : isUnlocked ? (
            <div className="text-center">
              <div className="text-cyan-400 text-2xl">✓</div>
              <p className="text-xs text-cyan-400 mt-1" style={{ fontFamily: 'Courier New, monospace' }}>
                UNLOCKED
              </p>
            </div>
          ) : (
            <p className="text-xs text-center px-4 text-cyan-400" style={{ fontFamily: 'Courier New, monospace' }}>
              TAP NFC HERE
            </p>
          )}
        </button>
      </div>

      {/* Timer */}
      <div className="text-center mb-4">
        <p className="text-xs mb-1 text-magenta-300" style={{ fontFamily: 'Courier New, monospace' }}>
          TIME REMAINING: {formatTime(timeRemaining)}
        </p>
      </div>

      {/* Warning */}
      <div className="absolute bottom-8 left-0 right-0 text-center px-4">
        <p className="text-sm font-bold mb-2 text-cyan-400" style={{ fontFamily: 'Courier New, monospace', textShadow: '0 0 10px rgba(0,255,255,0.6)' }}>
          WARNING: SIGNAL DECAYS IN 24 HOURS.
        </p>
        <p className="text-xs text-magenta-300" style={{ fontFamily: 'Courier New, monospace' }}>
          PROPERTY OF DIGITAL D.O.P.E. // QUIET LOUD
        </p>
      </div>

      {/* Unlock Modal */}
      {isUnlocked && (
        <div className="absolute inset-0 bg-black bg-opacity-95 flex items-center justify-center p-8">
          <div className="bg-black border-4 border-magenta-400 p-8 max-w-md text-center" style={{ boxShadow: '0 0 40px rgba(255,0,255,0.8)' }}>
            <h2 className="text-3xl font-bold mb-4 text-cyan-400" style={{ fontFamily: 'Courier New, monospace', textShadow: '0 0 20px rgba(0,255,255,0.8)' }}>
              CACHE UNLOCKED
            </h2>
            <div className="space-y-3 mb-6" style={{ fontFamily: 'Courier New, monospace' }}>
              <p className="text-xl text-magenta-400">✓ 500 D.O.P.E. CREDITS</p>
              <p className="text-sm text-cyan-300">Added to your account</p>
              <div className="border-t-2 border-cyan-400 my-4" style={{ boxShadow: '0 0 5px rgba(0,255,255,0.5)' }} />
              <p className="text-xl text-magenta-400">✓ UNRELEASED AUDIO STEMS</p>
              <p className="text-sm text-cyan-300">Download available in your vault</p>
            </div>
            <button
              onClick={() => setIsUnlocked(false)}
              className="bg-cyan-400 text-black px-6 py-3 font-bold hover:bg-cyan-300 transition-colors"
              style={{ fontFamily: 'Courier New, monospace', boxShadow: '0 0 20px rgba(0,255,255,0.6)' }}
            >
              CLOSE
            </button>
          </div>
        </div>
      )}
    </div>
  );
}