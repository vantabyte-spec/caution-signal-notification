import { useState, useEffect } from 'react';
import { CacheNotice } from './components/CacheNotice';

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <CacheNotice />
    </div>
  );
}